//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CdbUYtxa.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-Mkp-SjOf.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/query-D7ikszmN.js",
			"/assets/preload-helper-D_uw0iWl.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Mkp-SjOf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DV2KrPcZ.js", "/assets/sign-in-card-DUuq8FUZ.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-CjhkYvAC.js", "/assets/sign-in-card-DUuq8FUZ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
