import { n as createMiddleware } from "./ssr.mjs";
import { a as startOfMonth, c as startOfWeek, i as endOfWeek, l as addMonths, n as parseISO, o as eachDayOfInterval, r as format, s as endOfMonth, t as pl } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/present-BcvAaDRm.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-1vAx-gM_.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-CCc3DPlL.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var EVENT_COLORS = [
	{
		id: "",
		label: "Bez koloru"
	},
	{
		id: "#1c1917",
		label: "Atrament"
	},
	{
		id: "#2c4a3e",
		label: "Zieleń"
	},
	{
		id: "#8c4a3a",
		label: "Glina"
	},
	{
		id: "#3d5a73",
		label: "Stal"
	},
	{
		id: "#6b5344",
		label: "Umbra"
	},
	{
		id: "#3e5c5a",
		label: "Morska"
	}
];
var COLOR_IDS = new Set(EVENT_COLORS.map((c) => c.id));
var WEEKDAYS = [
	"Pn",
	"Wt",
	"Śr",
	"Cz",
	"Pt",
	"So",
	"Nd"
];
function todayIso(now = /* @__PURE__ */ new Date()) {
	return format(now, "yyyy-MM-dd");
}
function monthCursor(now = /* @__PURE__ */ new Date()) {
	return format(startOfMonth(now), "yyyy-MM-dd");
}
function shiftMonth(cursor, delta) {
	return format(addMonths(parseISO(cursor), delta), "yyyy-MM-dd");
}
function monthTitle(cursor) {
	const label = format(parseISO(cursor), "LLLL yyyy", { locale: pl });
	return label.charAt(0).toUpperCase() + label.slice(1);
}
function dayTitle(iso) {
	const label = format(parseISO(iso), "EEEE, d MMMM", { locale: pl });
	return label.charAt(0).toUpperCase() + label.slice(1);
}
function monthCells(cursor) {
	const start = startOfWeek(startOfMonth(parseISO(cursor)), { weekStartsOn: 1 });
	const end = endOfWeek(endOfMonth(parseISO(cursor)), { weekStartsOn: 1 });
	const days = eachDayOfInterval({
		start,
		end
	});
	while (days.length < 42) {
		const tail = days[days.length - 1];
		days.push(new Date(tail.getFullYear(), tail.getMonth(), tail.getDate() + 1));
	}
	return days.slice(0, 42).map((d) => format(d, "yyyy-MM-dd"));
}
function sameMonth(iso, cursor) {
	return iso.slice(0, 7) === cursor.slice(0, 7);
}
function eventDays(event) {
	const start = event.startDate || event.endDate;
	const end = event.endDate || event.startDate;
	if (!start || !end) return [];
	if (end < start) return [start];
	const days = eachDayOfInterval({
		start: parseISO(start),
		end: parseISO(end)
	});
	if (days.length > 370) return [start];
	return days.map((d) => format(d, "yyyy-MM-dd"));
}
function formatWhen(event) {
	const day = (iso) => format(parseISO(iso), "d MMM", { locale: pl }).replace(/\./g, "");
	const span = event.startDate && event.endDate && event.endDate !== event.startDate ? `${day(event.startDate)} – ${day(event.endDate)}` : event.startDate ? day(event.startDate) : event.endDate ? day(event.endDate) : "";
	const time = event.startTime && event.endTime ? `${event.startTime}–${event.endTime}` : event.startTime ? `od ${event.startTime}` : event.endTime ? `do ${event.endTime}` : "";
	if (span && time) return `${span} · ${time}`;
	return span || time || "Bez terminu";
}
function eventTitle(title) {
	return title.trim() || "Bez nazwy";
}
function plCount(n, one, few, many) {
	const abs = Math.abs(n);
	const m10 = abs % 10;
	const m100 = abs % 100;
	return `${n} ${abs === 1 ? one : m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14) ? few : many}`;
}
function errorText(err) {
	const raw = err instanceof Error ? err.message : "";
	if (/unauthorized/i.test(raw)) return "Sesja wygasła. Zaloguj się ponownie.";
	if (/nie |podaj |koniec |możesz |nieprawid|nie znaleziono|nie udało|hasło|konto|e-mail|email/i.test(raw)) return raw;
	return "Nie udało się zapisać. Spróbuj jeszcze raz.";
}
//#endregion
export { dayTitle as a, eventTitle as c, monthCursor as d, monthTitle as f, todayIso as g, shiftMonth as h, authMiddleware as i, formatWhen as l, sameMonth as m, EVENT_COLORS as n, errorText as o, plCount as p, WEEKDAYS as r, eventDays as s, COLOR_IDS as t, monthCells as u };
