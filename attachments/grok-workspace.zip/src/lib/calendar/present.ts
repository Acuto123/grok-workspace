import {
  addMonths,
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  parseISO,
  startOfMonth,
  startOfWeek,
} from "date-fns";
import { pl } from "date-fns/locale";

export type When = {
  startDate: string | null;
  endDate: string | null;
  startTime: string | null;
  endTime: string | null;
};

export const EVENT_COLORS: { id: string; label: string }[] = [
  { id: "", label: "Bez koloru" },
  { id: "#1c1917", label: "Atrament" },
  { id: "#2c4a3e", label: "Zieleń" },
  { id: "#8c4a3a", label: "Glina" },
  { id: "#3d5a73", label: "Stal" },
  { id: "#6b5344", label: "Umbra" },
  { id: "#3e5c5a", label: "Morska" },
];

export const COLOR_IDS = new Set(EVENT_COLORS.map((c) => c.id));

export const WEEKDAYS = ["Pn", "Wt", "Śr", "Cz", "Pt", "So", "Nd"] as const;

export function todayIso(now = new Date()): string {
  return format(now, "yyyy-MM-dd");
}

export function monthCursor(now = new Date()): string {
  return format(startOfMonth(now), "yyyy-MM-dd");
}

export function shiftMonth(cursor: string, delta: number): string {
  return format(addMonths(parseISO(cursor), delta), "yyyy-MM-dd");
}

export function monthTitle(cursor: string): string {
  const label = format(parseISO(cursor), "LLLL yyyy", { locale: pl });
  return label.charAt(0).toUpperCase() + label.slice(1);
}

export function dayTitle(iso: string): string {
  const label = format(parseISO(iso), "EEEE, d MMMM", { locale: pl });
  return label.charAt(0).toUpperCase() + label.slice(1);
}

export function monthCells(cursor: string): string[] {
  const start = startOfWeek(startOfMonth(parseISO(cursor)), { weekStartsOn: 1 });
  const end = endOfWeek(endOfMonth(parseISO(cursor)), { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start, end });
  while (days.length < 42) {
    const tail = days[days.length - 1];
    days.push(new Date(tail.getFullYear(), tail.getMonth(), tail.getDate() + 1));
  }
  return days.slice(0, 42).map((d) => format(d, "yyyy-MM-dd"));
}

export function sameMonth(iso: string, cursor: string): boolean {
  return iso.slice(0, 7) === cursor.slice(0, 7);
}

export function eventDays(event: When): string[] {
  const start = event.startDate || event.endDate;
  const end = event.endDate || event.startDate;
  if (!start || !end) return [];
  if (end < start) return [start];
  const days = eachDayOfInterval({ start: parseISO(start), end: parseISO(end) });
  if (days.length > 370) return [start];
  return days.map((d) => format(d, "yyyy-MM-dd"));
}

export function formatWhen(event: When): string {
  const day = (iso: string) => format(parseISO(iso), "d MMM", { locale: pl }).replace(/\./g, "");
  const span =
    event.startDate && event.endDate && event.endDate !== event.startDate
      ? `${day(event.startDate)} – ${day(event.endDate)}`
      : event.startDate
        ? day(event.startDate)
        : event.endDate
          ? day(event.endDate)
          : "";
  const time =
    event.startTime && event.endTime
      ? `${event.startTime}–${event.endTime}`
      : event.startTime
        ? `od ${event.startTime}`
        : event.endTime
          ? `do ${event.endTime}`
          : "";
  if (span && time) return `${span} · ${time}`;
  return span || time || "Bez terminu";
}

export function eventTitle(title: string): string {
  const trimmed = title.trim();
  return trimmed || "Bez nazwy";
}

export function plCount(n: number, one: string, few: string, many: string): string {
  const abs = Math.abs(n);
  const m10 = abs % 10;
  const m100 = abs % 100;
  const word =
    abs === 1 ? one : m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14) ? few : many;
  return `${n} ${word}`;
}

export function errorText(err: unknown): string {
  const raw = err instanceof Error ? err.message : "";
  if (/unauthorized/i.test(raw)) return "Sesja wygasła. Zaloguj się ponownie.";
  if (
    /nie |podaj |koniec |możesz |nieprawid|nie znaleziono|nie udało|hasło|konto|e-mail|email/i.test(
      raw,
    )
  ) {
    return raw;
  }
  return "Nie udało się zapisać. Spróbuj jeszcze raz.";
}
