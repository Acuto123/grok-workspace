import { useState, type FormEvent } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { Ban, Clock, MapPin, Trash2, X } from "lucide-react";
import {
  addProposal,
  applyProposal,
  createEvent,
  deleteEvent,
  deleteProposal,
  setRsvp,
  updateEvent,
  type EventInput,
  type EventRow,
  type MutationResult,
  type ProposalRow,
  type RsvpRow,
  type RsvpStatus,
} from "@/lib/calendar/api";
import { EVENT_COLORS, errorText, eventTitle, formatWhen } from "@/lib/calendar/present";
import { btnInk, btnLine, btnQuiet, fieldClass } from "@/components/controls";
import { twMerge } from "tailwind-merge";

type Mode = "create" | "event";

function blankEvent(day: string | null): EventInput {
  return {
    title: "",
    color: "",
    startDate: day ?? "",
    endDate: day ?? "",
    startTime: "",
    endTime: "",
    location: "",
  };
}

function toForm(event: EventRow): EventInput {
  return {
    title: event.title,
    color: event.color,
    startDate: event.startDate ?? "",
    endDate: event.endDate ?? "",
    startTime: event.startTime ?? "",
    endTime: event.endTime ?? "",
    location: event.location,
  };
}

export function EventDialog({
  mode,
  event,
  proposals,
  rsvps,
  me,
  initialDay,
  onClose,
  onResult,
}: {
  mode: Mode;
  event: EventRow | null;
  proposals: ProposalRow[];
  rsvps: RsvpRow[];
  me: string;
  initialDay: string | null;
  onClose: () => void;
  onResult: (result: MutationResult, close: boolean) => void;
}) {
  const [editing, setEditing] = useState(mode === "create");
  const [form, setForm] = useState<EventInput>(() =>
    mode === "create" || !event ? blankEvent(initialDay) : toForm(event),
  );
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [proposal, setProposal] = useState({
    startDate: event?.startDate ?? initialDay ?? "",
    startTime: "",
    endTime: "",
    note: "",
  });

  const mine = rsvps.find((row) => row.userId === me)?.status ?? null;

  function patch(partial: Partial<EventInput>) {
    setForm((current) => ({ ...current, ...partial }));
  }

  async function run(action: () => Promise<MutationResult>, close: boolean): Promise<boolean> {
    setPending(true);
    setError(null);
    try {
      const result = await action();
      onResult(result, close);
      return true;
    } catch (err) {
      setError(errorText(err));
      return false;
    } finally {
      setPending(false);
    }
  }

  async function saveEvent(submit: FormEvent) {
    submit.preventDefault();
    if (form.startDate && form.endDate && form.endDate < form.startDate) {
      setError("Koniec jest wcześniejszy niż początek");
      return;
    }
    if (mode === "create") {
      await run(() => createEvent({ data: form }), false);
      return;
    }
    if (!event) return;
    const ok = await run(() => updateEvent({ data: { ...form, id: event.id } }), false);
    if (ok) setEditing(false);
  }

  const names = (status: RsvpStatus) =>
    rsvps
      .filter((row) => row.status === status)
      .map((row) => (row.userId === me ? "Ty" : row.userName));

  return (
    <Dialog.Root open onOpenChange={(open) => { if (!open) onClose(); }}>
      <Dialog.Portal>
        <Dialog.Overlay className="sheet-backdrop fade-in" />
        <Dialog.Content className="sheet fade-in text-ink" aria-describedby="event-help">
          <div className="flex items-start justify-between gap-3">
            <Dialog.Title className="font-display text-2xl font-medium">
              {mode === "create"
                ? "Nowe wydarzenie"
                : editing
                  ? "Edycja wydarzenia"
                  : eventTitle(event?.title ?? "")}
            </Dialog.Title>
            <Dialog.Close className={btnQuiet} aria-label="Zamknij">
              <X className="size-4" />
            </Dialog.Close>
          </div>
          <Dialog.Description id="event-help" className="mt-1 text-sm text-muted">
            Nic nie jest wymagane. Puste pola można uzupełnić później.
          </Dialog.Description>

          {error ? (
            <p className="mt-3 text-sm text-danger" role="alert">
              {error}
            </p>
          ) : null}

          {editing ? (
            <form className="mt-4 grid gap-4" onSubmit={saveEvent}>
              <label className="grid gap-1 text-sm font-medium">
                Nazwa
                <input
                  id="event-title"
                  className={fieldClass}
                  value={form.title}
                  onChange={(input) => patch({ title: input.target.value })}
                  placeholder="np. Siłka"
                  maxLength={120}
                  autoComplete="off"
                />
              </label>

              <fieldset>
                <legend className="text-sm font-medium">Kolor</legend>
                <div className="mt-2 flex flex-wrap gap-2">
                  {EVENT_COLORS.map((swatch) => {
                    const selected = form.color === swatch.id;
                    return (
                      <button
                        key={swatch.id || "none"}
                        type="button"
                        aria-label={swatch.label}
                        aria-pressed={selected}
                        className={`grid size-11 place-items-center rounded-full border ${
                          selected ? "border-ink ring-2 ring-ink" : "border-line"
                        }`}
                        style={{ background: swatch.id || "transparent" }}
                        onClick={() => patch({ color: swatch.id })}
                      >
                        {swatch.id ? null : <Ban className="size-4 text-faint" aria-hidden="true" />}
                      </button>
                    );
                  })}
                </div>
              </fieldset>

              <fieldset>
                <legend className="text-sm font-medium">Dni</legend>
                <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                  <label className="grid gap-1 text-sm text-muted">
                    Od
                    <input
                      id="event-start-date"
                      className={fieldClass}
                      type="date"
                      value={form.startDate}
                      onChange={(input) => patch({ startDate: input.target.value })}
                    />
                  </label>
                  <label className="grid gap-1 text-sm text-muted">
                    Do
                    <input
                      id="event-end-date"
                      className={fieldClass}
                      type="date"
                      value={form.endDate}
                      onChange={(input) => patch({ endDate: input.target.value })}
                    />
                  </label>
                </div>
              </fieldset>

              <fieldset>
                <legend className="text-sm font-medium">Godziny</legend>
                <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                  <label className="grid gap-1 text-sm text-muted">
                    Od
                    <input
                      id="event-start-time"
                      className={fieldClass}
                      type="time"
                      value={form.startTime}
                      onChange={(input) => patch({ startTime: input.target.value })}
                    />
                  </label>
                  <label className="grid gap-1 text-sm text-muted">
                    Do
                    <input
                      id="event-end-time"
                      className={fieldClass}
                      type="time"
                      value={form.endTime}
                      onChange={(input) => patch({ endTime: input.target.value })}
                    />
                  </label>
                </div>
              </fieldset>

              <label className="grid gap-1 text-sm font-medium">
                Miejsce
                <input
                  id="event-location"
                  className={fieldClass}
                  value={form.location}
                  onChange={(input) => patch({ location: input.target.value })}
                  placeholder="np. siłownia na Grunwaldzkiej"
                  maxLength={200}
                  autoComplete="off"
                />
              </label>

              {form.startDate || form.endDate || form.startTime || form.endTime ? (
                <button
                  type="button"
                  className={`${btnQuiet} justify-start px-0`}
                  onClick={() =>
                    patch({ startDate: "", endDate: "", startTime: "", endTime: "" })
                  }
                >
                  Wyczyść termin
                </button>
              ) : null}

              <div className="flex flex-wrap gap-2">
                <button id="save-event" className={btnInk} type="submit" disabled={pending}>
                  {pending ? "Zapisywanie…" : mode === "create" ? "Dodaj wydarzenie" : "Zapisz zmiany"}
                </button>
                {mode === "event" ? (
                  <button
                    type="button"
                    className={btnLine}
                    onClick={() => {
                      if (event) setForm(toForm(event));
                      setEditing(false);
                      setError(null);
                    }}
                  >
                    Anuluj
                  </button>
                ) : null}
              </div>
            </form>
          ) : event ? (
            <div className="mt-4 grid gap-5">
              <div className="flex gap-3">
                <span
                  className="mt-1 h-12 w-1.5 shrink-0 rounded-full"
                  style={{ background: event.color || "var(--color-line-strong)" }}
                />
                <div className="min-w-0">
                  <p className="text-sm text-muted tabular-nums">{formatWhen(event)}</p>
                  {event.location ? (
                    <p className="mt-1 flex items-center gap-1 text-sm">
                      <MapPin className="size-4 shrink-0" aria-hidden="true" />
                      <span className="break-words">{event.location}</span>
                    </p>
                  ) : (
                    <p className="mt-1 text-sm text-faint">Bez miejsca</p>
                  )}
                  <p className="mt-1 text-sm text-faint">Od {event.creatorName}</p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold">Kto przychodzi</h3>
                <div className="mt-2 grid grid-cols-3 gap-2">
                  {(
                    [
                      ["yes", "Przyjdę"],
                      ["maybe", "Może"],
                      ["no", "Nie przyjdę"],
                    ] as const
                  ).map(([status, label]) => (
                    <button
                      key={status}
                      type="button"
                      aria-pressed={mine === status}
                      disabled={pending}
                      className={twMerge(mine === status ? btnInk : btnLine, "h-auto min-h-11 w-full px-1 text-center")}
                      onClick={() =>
                        void run(
                          () =>
                            setRsvp({
                              data: {
                                eventId: event.id,
                                status: mine === status ? "clear" : status,
                              },
                            }),
                          false,
                        )
                      }
                    >
                      {label}
                    </button>
                  ))}
                </div>
                <div className="mt-2 grid gap-1 text-sm text-muted">
                  {names("yes").length > 0 ? <p>Przyjdą: {names("yes").join(", ")}</p> : null}
                  {names("maybe").length > 0 ? <p>Może: {names("maybe").join(", ")}</p> : null}
                  {names("no").length > 0 ? <p>Nie przyjdą: {names("no").join(", ")}</p> : null}
                  {rsvps.length === 0 ? <p>Nikt jeszcze nie zaznaczył obecności.</p> : null}
                </div>
              </div>

              <div>
                <h3 className="flex items-center gap-2 text-sm font-semibold">
                  <Clock className="size-4" aria-hidden="true" />
                  Propozycje godzin
                </h3>
                {proposals.length === 0 ? (
                  <p className="mt-2 text-sm text-muted">
                    Nikt jeszcze nie podał godziny. Dopisz swoją — reszta grupy ją zobaczy.
                  </p>
                ) : (
                  <ul className="mt-2 divide-y divide-line">
                    {proposals.map((item) => (
                      <li key={item.id} className="grid gap-1 py-3">
                        <p className="text-sm font-semibold">
                          {item.userId === me ? "Ty" : item.userName}
                        </p>
                        <p className="text-sm tabular-nums text-muted">
                          {formatWhen(item)}
                        </p>
                        {item.note ? (
                          <p className="font-display text-base italic text-muted">{item.note}</p>
                        ) : null}
                        <div className="flex flex-wrap gap-2">
                          <button
                            type="button"
                            className={btnLine}
                            disabled={pending}
                            onClick={() => void run(() => applyProposal({ data: item.id }), false)}
                          >
                            Ustaw jako termin
                          </button>
                          {item.userId === me ? (
                            <button
                              type="button"
                              className={btnQuiet}
                              disabled={pending}
                              onClick={() => void run(() => deleteProposal({ data: item.id }), false)}
                            >
                              Usuń
                            </button>
                          ) : null}
                        </div>
                      </li>
                    ))}
                  </ul>
                )}

                <form
                  className="mt-3 grid gap-2"
                  onSubmit={(submit) => {
                    submit.preventDefault();
                    void run(
                      () =>
                        addProposal({
                          data: {
                            eventId: event.id,
                            startDate: proposal.startDate,
                            endDate: proposal.startDate,
                            startTime: proposal.startTime,
                            endTime: proposal.endTime,
                            note: proposal.note,
                          },
                        }),
                      false,
                    ).then((ok) => {
                      if (!ok) return;
                      setProposal({
                        startDate: event.startDate ?? "",
                        startTime: "",
                        endTime: "",
                        note: "",
                      });
                    });
                  }}
                >
                  <p className="text-sm font-medium">Twoja propozycja</p>
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                    <input
                      id="proposal-date"
                      aria-label="Dzień propozycji"
                      className={fieldClass}
                      type="date"
                      value={proposal.startDate}
                      onChange={(input) =>
                        setProposal((current) => ({ ...current, startDate: input.target.value }))
                      }
                    />
                    <input
                      id="proposal-start"
                      aria-label="Godzina od"
                      className={fieldClass}
                      type="time"
                      value={proposal.startTime}
                      onChange={(input) =>
                        setProposal((current) => ({ ...current, startTime: input.target.value }))
                      }
                    />
                    <input
                      id="proposal-end"
                      aria-label="Godzina do"
                      className={fieldClass}
                      type="time"
                      value={proposal.endTime}
                      onChange={(input) =>
                        setProposal((current) => ({ ...current, endTime: input.target.value }))
                      }
                    />
                  </div>
                  <input
                    id="proposal-note"
                    className={fieldClass}
                    value={proposal.note}
                    onChange={(input) =>
                      setProposal((current) => ({ ...current, note: input.target.value }))
                    }
                    placeholder="Notatka, np. po pracy"
                    maxLength={280}
                  />
                  <button id="add-proposal" className={btnInk} type="submit" disabled={pending}>
                    Zaproponuj godzinę
                  </button>
                </form>
              </div>

              <div className="flex flex-wrap gap-2 border-t border-line pt-4">
                <button
                  type="button"
                  className={btnLine}
                  onClick={() => {
                    setForm(toForm(event));
                    setEditing(true);
                    setError(null);
                  }}
                >
                  Edytuj
                </button>
                {confirmDelete ? (
                  <button
                    type="button"
                    className={twMerge(btnInk, "bg-danger")}
                    disabled={pending}
                    onClick={() => void run(() => deleteEvent({ data: event.id }), true)}
                  >
                    <Trash2 className="size-4" aria-hidden="true" />
                    Potwierdź usunięcie
                  </button>
                ) : (
                  <button
                    type="button"
                    className={`${btnQuiet} text-danger`}
                    onClick={() => setConfirmDelete(true)}
                  >
                    Usuń
                  </button>
                )}
              </div>
            </div>
          ) : null}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
